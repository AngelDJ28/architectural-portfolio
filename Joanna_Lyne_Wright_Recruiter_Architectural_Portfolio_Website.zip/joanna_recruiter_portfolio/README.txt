JOANNA LYNE WRIGHT — RECRUITER ARCHITECTURAL PORTFOLIO WEBSITE

Open index.html in a browser. Upload the entire folder to Netlify, GitHub Pages, Cloudflare Pages, or another static web host. Keep the assets folder and PDF beside index.html.

Project contribution text is intentionally conservative where the source portfolio does not specify exact individual responsibilities per image. Add verified project-specific roles before public publication if desired.
